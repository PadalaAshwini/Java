package Ashu;

public class FahrenheitToCelsiusConverterr {

	public static void main(String[] args) {
        // Predefined value for temperature in Fahrenheit
        double fahrenheit = 98.6;

        // Convert Fahrenheit to Celsius
        double celsius = (fahrenheit - 32) * 5 / 9;

        // Output the result
        System.out.println("Temperature in Celsius: " + celsius + " °C");
    }
}
	


