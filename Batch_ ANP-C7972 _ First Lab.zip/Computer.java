package SecondProgram;

public class Computer {

	public static void main(String[] args) {
		System.out.println("computer is a electronic device");
		System.out.println("computer has components like moniter,keyboard,cpu,mouse");
		System.out.println("it is invented by charles bage");
		System.out.println("he also known as father of computer ");
		System.out.println("it is understand only binary language");
		System.out.println("binary lan reffered as 0's and 1's");
		System.out.println("to complete course practice");
		System.out.println("to create the test material");
		System.out.println("to plane and shcedule");
		System.out.println("to moniter library data ");


	}

}
