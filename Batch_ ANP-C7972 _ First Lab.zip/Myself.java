package FirstProgram;

public class Myself {


		
	
		   public static void main(String[] args)
			{
				System.out.println("my name is Ashwini"); 
				System.out.println("I am from kolkulpally");
				System.out.println("I am pursuing mca in avanthi pg college");
				System.out.println("I hava completed my graduation from Bsc");
				System.out.println("I have completed my inter from MPC");
				System.out.println("I have completed my ssc ");
				System.out.println("my father name is Yadaiah");
				System.out.println("my mother name is Sugunamma");
				System.out.println("my brother name is Ravi");
				System.out.println("my sister name is Mahalaxmi");
			}

		}	

	


