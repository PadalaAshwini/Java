package SecondProgram;

public class JVM {

	public static void main(String[] args) {
		System.out.println("JVM stands for java virtual machine ");
		System.out.println("using compiler source code is converted into byte code");
		System.out.println("by using interpreter byte code can be converted into machine code");
		System.out.println("java architecture have 3 components");
		System.out.println("1.Class Loader");
		System.out.println("2.Runtime Memory");
		System.out.println("3.Execution Engine");
		System.out.println("class loader loads class");
		System.out.println("it has loading,linking,initialization components");
		System.out.println("main method() is 1st loaded into the main memory");
		System.out.println("bootstrap have a root class extention");
		System.out.println("jvm is an abstract machine ");
		System.out.println("jvm is  has many hardware and software platforms");
		System.out.println("jvm is a platform independent");
		System.out.println("jvm follows oops concept");
		


	}

}
